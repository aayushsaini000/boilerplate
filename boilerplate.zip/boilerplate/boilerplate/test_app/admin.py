"""
from django.contrib import admin

# Register your models here.
from django.contrib.auth.models import Group
from Event_Lobby.models import PageConfiguration,SponsorLogo,Hotspot,BrandingImageDetail,BrandingImage
from django.forms import ModelChoiceField
from django import forms
from rest_framework.authtoken.models import Token



class PageConfigurationAdmin(admin.ModelAdmin):
    exclude = ('subdomain',)
    list_display = ('enable','pagetitle','background_image','video_type','vimeo_link','youtube_link','left','top','width','height')
    def has_add_permission(self, request):
        base_add_permission = super(PageConfigurationAdmin, self).has_add_permission(request)
        if base_add_permission:
            # if there's already an entry, do not allow adding
            count = PageConfiguration.objects.filter(subdomain_id=request.user.subdomain_id).count()
            if count == 0:
                return True
        return False
    def has_module_permission(self, request):
        if request.user.is_superuser:
            return False
        else:
            return True
    def save_model(self, request, obj, form, change):
        obj.subdomain_id = request.user.subdomain_id
        super().save_model(request, obj, form, change)
    def get_queryset(self, request):
        qs = super(PageConfigurationAdmin, self).get_queryset(request)
        if request.user.is_superuser:
            self.has_module_permission
        if request.user.is_staff:
            return qs.filter(subdomain_id=request.user.subdomain_id)
"""