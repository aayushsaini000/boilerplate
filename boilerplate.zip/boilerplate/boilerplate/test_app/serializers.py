"""
from rest_framework import serializers
from test_app.models import ()



class PageConfigurationSerializer(serializers.ModelSerializer):
    class Meta:
        model = PageConfiguration
        fields = '__all__'
"""