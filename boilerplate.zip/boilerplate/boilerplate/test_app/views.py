"""
from django.shortcuts import render
from Event_Lobby.models import PageConfiguration,SponsorLogo,Hotspot,BrandingImageDetail,BrandingImage,SubDomain
from Event_Lobby.serializers import PageConfigurationSerializer,SponsorLogosSerializer,HotspotsSerializer,BrandingImageSerializer,BrandingImageDeatilsSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from cexpo.settings import API_VERIFICATION_SECRET_KEY
from rest_framework import status

class PageConfigurationView(APIView):
    def get(self, request,subdomain):
        if 'Authorization' in request.headers:
            token = request.headers['Authorization']
            if token == API_VERIFICATION_SECRET_KEY:
                try:
                    subdomain_check = SubDomain.objects.get(subdomain=subdomain)
                except Exception:
                    data = {
                    "error": True,
                    "msg": "Subdomain not registered"
                    }
                    return Response(data, status=status.HTTP_404_NOT_FOUND)
                all_images = PageConfiguration.objects.all().filter(subdomain_id=subdomain_check.id)
                serializer = PageConfigurationSerializer(all_images, many=True)
                return Response(serializer.data)
            else:
                data = {
                    "error": True,
                    "msg": "Token is invalid"
                }
                return Response(data, status=status.HTTP_401_UNAUTHORIZED)
        else:
            data = {
                "error": True,
                "msg": "Header not a Authorization key"
            }
            return Response(data, status=status.HTTP_401_UNAUTHORIZED)
"""
