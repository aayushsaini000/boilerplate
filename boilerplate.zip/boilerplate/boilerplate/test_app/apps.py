from django.apps import AppConfig


class TestAppConfig(AppConfig):
    name = 'test_app'
